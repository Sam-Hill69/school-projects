/*  JavaScript 7th Edition
    Chapter 1
    Hands-On Project 1-2

    Author: Samuel Hill
    Date:   09-26-2025

    Filename: project01-02.js
*/

//define variables for service name and service speed
let service1Name = "Basic",
  service2Name = "Express",
  service3Name = "Extreme",
  service4Name = "Ultimate";
let service1Speed = "0 Mbps",
  service2Speed = "100 Mbps",
  service3Speed = "500 Mbps",
  service4Speed = "1 Gig";
