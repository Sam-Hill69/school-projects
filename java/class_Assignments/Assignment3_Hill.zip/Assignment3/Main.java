 /*
 * Author:              Samuel Hill   
 * Date:                  10-01-2025  
 * Assignment:      Assignment 3  main.java
 * Description:      This is the main portion of the project that brings everything together and runs the program
 *                        
 */
import java.util.Scanner;

public class Main {

  public static void main(String[] args) {

    Scanner keyboard = new Scanner(System.in);
    boolean running = true;

    while (running) {

      System.out.println("---------------------------------------");
      System.out.println("Welcome to Home Inspection & Repair Co.");
      System.out.println("---------------------------------------");
      System.out.println("1: Inspection Service");
      System.out.println("2: Repair Service");
      System.out.println("3: Emergency Service");
      System.out.println("0: Exit");

      int serviceType = keyboard.nextInt();

      if (serviceType == 1) {
        InspectionService inspection = new InspectionService(
          gatherDouble("Enter inspection fee $: "),
          gatherInt("Enter invoice #: "),
          gatherString("Enter first name: "),
          gatherString("Enter last name: "),
          gatherBoolean("Is the customer qualified for a discount? (Y or N): "),
          gatherDouble("Enter discount rate (12 for 12%): ")
        );
        System.out.println("\nInvoice #: " + inspection.getInvoiceNumber());
        System.out.println("Customer Name: " + inspection.getFirstName() + " " + inspection.getLastName());
        System.out.println("Discount Status: " + inspection.getDiscountStatus());
        System.out.println("Discount Rate: " + inspection.getDiscountRate() * 100 + "%");
        System.out.println("Inspection Fee: $" + inspection.getServiceCharge());
        System.out.println("Inspection Charge with Discount: $" + inspection.calculateCost());
      } else if (serviceType == 2) {
        RepairService repair = new RepairService(
          gatherInt("Enter hours worked: "),
          gatherDouble("Enter hourly rate: "),
          gatherInt("Enter invoice #: "),
          gatherString("Enter first name: "),
          gatherString("Enter last name: "),
          gatherBoolean("Is the customer qualified for a discount? (Y or N): "),
          gatherDouble("Enter discount rate (12 for 12%): ")
        );
        System.out.println("\nInvoice #: " + repair.getInvoiceNumber());
        System.out.println("Customer Name: " + repair.getFirstName() + " " + repair.getLastName());
        System.out.println("Discount Status: " + repair.getDiscountStatus());
        System.out.println("Discount Rate: " + repair.getDiscountRate() * 100 + "%");
        System.out.println("Hours Worked: " + repair.getHoursWorked());
        System.out.println("Hourly Rate: $" + repair.getHourlyRate());
        System.out.println("Repair Charge with Discount: $" + repair.calculateCost());
      } else if (serviceType == 3) {
        EmerencyService emergency = new EmerencyService(
          gatherDouble("Enter emergency rate: "),
          gatherInt("Enter invoice #: "),
          gatherString("Enter first name: "),
          gatherString("Enter last name: "),
          gatherBoolean("Is the customer qualified for a discount? (Y or N): "),
          gatherDouble("Enter discount rate (12 for 12%): "),
          gatherDouble("Enter hourly rate: "),
          gatherInt("Enter hours worked: ")
        );
        System.out.println("\nInvoice #: " + emergency.getInvoiceNumber());
        System.out.println("Customer Name: " + emergency.getFirstName() + " " + emergency.getLastName());
        System.out.println("Discount Status: " + emergency.getDiscountStatus());
        System.out.println("Discount Rate: " + emergency.getDiscountRate() * 100 + "%");
        System.out.println("Emergency Rate: $" + emergency.getEmergencyRate());
        System.out.println("Emergency Charge with Discount: $" + emergency.calculateCost());
      } else if (serviceType == 0) {
        running = false;
      }
    }
  }

  public static String gatherString(String prompt) {
    System.out.print(prompt);
    return new Scanner(System.in).nextLine();
  }

  public static int gatherInt(String prompt) {
    System.out.print(prompt);
    return new Scanner(System.in).nextInt();
  }

  public static double gatherDouble(String prompt) {
    System.out.print(prompt);
    return new Scanner(System.in).nextDouble();
  }

  public static boolean gatherBoolean(String prompt) {
    System.out.print(prompt);
    return new Scanner(System.in).nextLine().equalsIgnoreCase("Y");
  }
}
