"use strict";
/*    JavaScript 7th Edition
      Chapter 9
      Project 09-01

      Project to read field values from a query string
      Author: Samuel Hill 
      Date:   11-24-2025

      Filename: project09-01b.js
*/

