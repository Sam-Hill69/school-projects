/*  JavaScript 7th Edition
    Chapter 1
    Hands-On Project 1-4

    Author: 
    Date:   

    Filename: project01-04.js
*/

//define variables for home and work addresses

