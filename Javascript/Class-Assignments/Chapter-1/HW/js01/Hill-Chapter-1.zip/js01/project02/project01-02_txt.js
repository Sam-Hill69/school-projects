/*  JavaScript 7th Edition
    Chapter 1
    Hands-On Project 1-2

    Author: Samuel Hill
    Date:   09-26-2025

    Filename: project01-02.js
*/

//define variables for service name and service speed
